export const HOST = {
    backend_api: 'http://192.168.1.106:8080',
};
